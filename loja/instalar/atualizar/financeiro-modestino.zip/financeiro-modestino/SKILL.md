---
name: "financeiro-modestino"
description: "Use quando Jorge ou Lucas informarem venda, recebimento, gasto, brinde, defeito, aporte ou mudança de estoque da Modestino: lança no Painel da Modestino com as regras da casa."
---

# Setor Financeiro da Modestino — lançar no painel

O Painel da Modestino é a fonte única dos números (vendas, estoque, custos, caixa, aportes, marketing e placar de metas): https://claude.ai/code/artifact/a01898d2-619b-47f4-a7fe-3d585a03f95a
Os dados ficam no arquivo `data/state.json` do artifact. O histórico e as decisões ficam no doc do projeto `claude/fluxo-caixa-modestino.md`.

## Passo a passo

1. Leia `data/state.json` com o Artifact tool (`action: read`, `path: data/state.json`) ANTES de editar: os sócios lançam pelo celular e o arquivo muda.
2. Edite o JSON com Python (nunca reescreva à mão). Estrutura:
   - `sales[]`: `{id, date, client, items, lines:[{color: preta|marrom|off, size: P|M|G|GG, qty, lot:'L1'}], qty, price, received, method, due, note, seller}`. `received` = quanto entrou de fato; o resto aparece como "a receber". `seller`: Jorge, Lucas, "Paulo Vitor (cupom)", "Kianu (cupom)" ou "Outro embaixador".
   - `entries[]` (custos): `{id, date, category, kind, description, value, status, note}`. category: tecido, desenvolvimento, confeccao, estamparia, aviamentos, logistica, etiqueta, branding, marketing, taxas, equipamento, outros. kind: investimento | fixo | variavel. status: pago | pendente | a-pedir.
   - `moves[]` (saídas sem venda): `{id, date, type: brinde|defeito|uso|extravio|outro, lines, note}`.
   - `aportes[]`: `{id, date, type: aporte|devolucao, jorge, lucas, note}` — sempre 50/50 salvo aviso.
   - `stock.lots[]`, `goals`, `marketing`, `bsc` (não mexer sem pedido).
3. Publique: `Artifact publish` com `url` do painel, `file_path` = o index.html salvo da versão atual e `files: {"data/state.json": <arquivo editado>}`. Se a publicação for recusada por versão nova, leia o arquivo indicado por inteiro e publique de novo a partir dele — nunca reenvie uma versão antiga do index.html.
4. Atualize `claude/fluxo-caixa-modestino.md` no projeto com uma linha por lançamento relevante.
5. Responda curto: o que foi lançado (tabela se houver mais de um item), estoque e caixa resultantes, e só as confirmações que faltam.

## Vendas da loja virtual

Pedido pago na loja (Shopify ou outra) entra em `sales[]` como qualquer venda: `method` = forma real (Pix, Cartão), `note` = "loja online #<número do pedido>", cupom de embaixador em `seller`. Taxa do gateway vai para `entries` (categoria taxas). Depois de lançar, rode `catalogo-modestino` para a loja ficar com o mesmo estoque do Painel.

## Regras da casa

- Preço cheio: R$ 80 a peça. Promoção sem embalagem: R$ 75 ou R$ 70. Kit 2 R$ 160 (R$ 150 sem embalagem), kit 3 R$ 225 (confirmado em 27/10/2026). Empresas: kit 3 a R$ 210 (10 a 29 kits) e R$ 195 (30+). Margem mínima 50% por venda; meta de margem média 65%.
- Nunca assumir "Pago" num custo sem confirmação; nunca assumir preço ou forma de pagamento sem marcar "confirmar" na observação e perguntar.
- Taxa de maquininha vira custo separado (categoria taxas) e a venda fica com o valor bruto.
- Brinde, uso de sócio, defeito e extravio saem do estoque como `moves`, nunca como venda.
- Aporte: os sócios cobrem o que faltar no caixa no dia, 50/50. Gastos pagos com dinheiro da conta não são aporte.
- A conta da loja deve bater com o caixa do painel; diferença vira pergunta, não ajuste silencioso.
- Avisar sempre: próxima conta (parcela do tecido) x caixa + a receber, peças/aporte que faltam, e grade acabando (pedir lote novo com 50 peças).