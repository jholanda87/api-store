---
name: "site-impecavel-modestino"
description: "Use quando Jorge pedir landing page, site, página de produto ou loja da Modestino: cria no padrão da skill Impeccable (diretor de design) com a identidade da marca."
---

# Site e landing page da Modestino (método Impeccable adaptado)

Versão adaptada da skill pública Impeccable (github.com/pbakaus/impeccable, licença Apache 2.0), sem o programa executável que ela baixa. Trabalhe como um diretor de design premiado: código pronto para produção, ponto de vista claro e acabamento excepcional.

## Antes de criar

1. Leia `claude/00-central-modestino.md`, `claude/identidade-modestino-logotipos.md` e `claude/fila-posts-modestino.md` (o que já saiu no Instagram, para o site conversar com o feed).
2. O mundo visual já existe: **herde, não reinvente.** Linho #ECE7DE / #E4DDD0, carvão #22201D / #1E1D1C, mapple #5B3F30, areia #CBBFAE, grafite #6E675F (texto secundário sobre linho: #5F5850, porque #6E675F não passa 4,5:1). Instrument Serif nos títulos (itálico para a ênfase), Instrument Sans no texto e no nome MODESTINO espaçado, Geist Mono só para preço, medida e dado.
3. Fotos reais, nunca banco de imagem nem IA: frames dos vídeos do Keanu (pasta "Vídeo Keanu" no Drive, tempos em `claude/mapa-takes-keanu.md`), fotos das golas com a etiqueta (`_edicao_claude/referencias_higgsfield/1_tres_cores_golas.jpg`, `3_marrom_tecido.jpg`), mockup da ecobag. Nunca 2_preta_vestida nem 4_espelho_preta.
4. Fatos só confirmados: R$ 80 a avulsa, P ao GG, kit com 3 por R$ 225, cores Preto / Mapple Brown / Off White, entrega rápida e troca em mãos em Fortaleza, ecobag só nos kits. Largura (axila a axila) P 51 · M 54 · G 57 · GG 60 cm; tórax 102 · 108 · 114 · 120 cm. Ombro mede-se da costura da gola até a costura da manga. O que não estiver confirmado vira [PLACEHOLDER] e pergunta ao Jorge.

## Regras da marca

- Modal é um dos tecidos, não o único; composição só por peça ("vem na etiqueta").
- Um básico para cada ocasião; nunca a mesma peça em sequência no mesmo dia.
- Duas linhas: a Básica é lisa, sem logo na frente; a Estampada tem arte autoral e pode levar o Cavalheiro na roupa. Não misture as duas no mesmo bloco.
- Não nomear quem costura.

## Modo e estrutura (Persuade)

- **A primeira tela é uma tese, não um cabeçalho.** Ela mostra a oferta, desperta desejo, tem a ação principal visível e prova algo que só a Modestino prova. Teste: se a pessoa sair depois da primeira tela, o que ela descreveria uma hora depois?
- **A ação é a do negócio, na forma real:** hoje, pedir no Direct (https://ig.me/m/lojamodestino) com a cor escolhida; quando houver loja, adicionar ao carrinho.
- **Prove, não afirme:** seletor de cor que troca foto e fundo, calculadora de tamanho pela largura da camiseta que a pessoa já tem, fotos de perto (gola, ombro, costas).
- **Ritmo de estúdio:** alternar densidade, escala e fundo (linho, carvão, mapple) dentro da mesma gramática; terminar com um fechamento forte (busto do Cavalheiro + MODESTINO + ação).
- **Um movimento autoral só**, com ease-out exponencial a partir de um estado já visível (ex.: a troca de cor do hero). Nada de animação igual em toda seção.

## Proibido (padrões genéricos)

- Cards iguais de ícone + título + texto como estrutura da página; card dentro de card.
- Texto pequeno acima do título (eyebrow/kicker) e numeração de seção (01 / 02 / 03).
- Hero de número gigante com estatísticas; gradiente no texto; vidro/blur decorativo; borda colorida grossa na lateral de cards; sombra dura sem desfoque.
- Emoji ou símbolo unicode no lugar de ícone (ícone é SVG de traço único).
- Máscara geométrica fingindo recorte de foto.
- Fonte do sistema como título.

## Piso de qualidade (conferir no resultado renderizado)

- Contraste: texto ≥ 4,5:1, texto grande ≥ 3:1; texto secundário sobre cor tingido da própria cor, nunca cinza.
- Sombras com deslocamento e desfoque suave.
- Espaço maior acima do título do que abaixo; grupos próximos, seções bem separadas.
- Texto corrido com 65–75 caracteres por linha; título até ~6rem; espaçamento de letra nunca abaixo de -0,04em.
- Estados: hover, foco do teclado, vazio, erro (ex.: calculadora com medida fora da tabela).
- Superfícies do navegador com a paleta: seleção de texto, anel de foco, cor de acento dos inputs, números tabulares em preço e medida.
- Funciona no celular (390 px): menus quebram, colunas empilham, tabela rola dentro de uma caixa. Botões com no mínimo 44 px.
- Acessível: `<button>`, `<a href>`, `<input>` + `<label>`, `alt` descritivo em toda foto, `aria-live` no resultado da calculadora.

## Onde entregar

- Protótipo e aprovação: artefato do tipo Design (canvas), uma página com `expand: fill`. Fotos sobem como assets do artefato.
- Referência aprovada em 21/10/2026: canvas "Modestino — Landing page" (https://claude.ai/artifact/LHvLezpo2QHYFH5u6GUs6J).
- Site no ar: só quando Jorge decidir domínio e hospedagem (ex.: Shopify, que já tem conector; ou hospedagem paga com domínio próprio). Não contratar nada sem aprovação.

## Comandos úteis (vindos da Impeccable)

- **critique:** revisão de UX com nota por heurística (hierarquia, clareza da oferta, ação, prova, confiança).
- **audit:** contraste, acessibilidade, responsivo, desempenho (peso das fotos).
- **polish:** passada final antes de publicar.
- **bolder / quieter:** deixar mais ousado ou mais sóbrio sem sair da identidade.
- **clarify:** revisar textos de botão, erro e ajuda na voz da marca (direta, curta, sem tom de coach).

Inspecione no máximo duas rodadas (desktop 1440 e celular 390), corrigindo em lote entre elas. Registre a decisão no projeto ao terminar.