---
name: "criar-conteudo-modestino"
description: "Use quando Jorge pedir post, carrossel, roteiro de reels, stories ou ideias de conteúdo para o Instagram da Modestino: cria com o método validado e a identidade oficial."
---

# Criar conteúdo para o Instagram da Modestino

A Modestino é uma marca de básicos masculinos de Fortaleza (Jorge e o sócio Lucas), no Instagram @lojamodestino. Esta habilidade junta duas coisas: a identidade oficial da marca e o método de conteúdo que mais performou na análise de 230 posts do @renatoduran07 (ago a out/2026). A análise completa está no doc do projeto `claude/aprendizados-renato-duran.md`; a identidade em `claude/identidade-modestino-logotipos.md`. Leia os dois antes de criar.

## Regras da marca (não negociáveis)

- **Tecido:** modal é um dos tecidos, não o único. Nunca apresente modal como o tecido da marca. Composição só por peça.
- **Ocasião:** "qualquer ocasião" quer dizer ter uma opção de básico para cada ocasião. Nunca sugira usar a mesma peça em sequência (nada de "do treino ao jantar sem trocar", nada de horários seguidos no mesmo dia).
- **Camisetas (duas linhas, decisão de 30/10/2026):** a Básica é lisa, sem logo, só o nome MODESTINO pequeno na nuca interna. A Estampada tem arte autoral e minimalista e pode levar o Cavalheiro (busto no peito, figura e nome, cartola nas costas). Nunca misture as duas no mesmo post como se fossem a mesma peça. Estampa em post: só foto real da peça ou, antes da amostra, mockup marcado como "prévia".
- **Venda:** não vender de cara. Primeiro pergunta, curiosidade ou utilidade; o produto aparece como consequência.
- **Voz:** humano, direto, nada engessado. Frases curtas. Sem emoji em excesso.
- **Visual:** linho #ECE7DE, carvão #22201D, mapple #5B3F30, areia #CBBFAE, grafite #6E675F. Instrument Serif (títulos, itálico para a ênfase), Instrument Sans 600 espaçado (nome), Geist Mono (legendas pequenas). Logo O Cavalheiro (desenho à mão) só em capa, última lâmina, avatar e embalagem.

## O método (o que performou)

1. **Carrossel de uma afirmação por lâmina.** 5 a 7 lâminas, 1080×1350. Cada lâmina é uma regra curta, específica e útil, que funciona sozinha. Quase sem design: fundo liso, texto grande. Para a Modestino: fundo linho ou carvão, título em Instrument Serif.
2. **Gancho específico na capa.** Os campeões usam:
   - regra com número ou situação concreta ("Se a manga passa do meio do bíceps, a camiseta está grande");
   - "Se você fizer X, Y acontece" ("Se você lavar a camiseta preta do avesso, ela desbota menos");
   - contrário ao senso comum ("Camiseta larga não disfarça barriga");
   - instrução para amanhã ("Amanhã, antes de sair, confira estes 3 pontos no espelho");
   - passo a passo com foto circulada (como medir a camiseta que você já tem).
   Marque uma palavra-chave da capa com fundo areia, como o destaque amarelo dele.
3. **Evite o que performou mal:** temas amplos ("guia completo de estilo"), listas longas numa lâmina, "40 ideias de…".
4. **Última lâmina fixa da marca:** o cavalheiro pequeno + uma pergunta ou pedido de salvar. Exemplos: "Pegou o ponto? Salva para a próxima compra.", "Qual dessas você já errou? Comenta." Não peça para comprar.
5. **Legenda curta e fixa,** com a pergunta e o pedido de comentário (ex.: "Comenta MEDIDAS que a gente te ajuda com o tamanho."). O conteúdo fica nas lâminas.
6. **Repostar campeões.** Um carrossel que foi bem pode voltar 3 a 4 semanas depois, com capa nova.
7. **Reels** (dicas dele, use como teste, não como verdade): fazer a última edição dentro do Instagram (título), cortar silêncios, ter um objeto na mão, começar sentado e levantar, mirar ~40 s, gravar de frente para luz natural. Qualidade premium: descartar imagem mal gravada, manter enquadramento padrão.
8. **Stories** (dicas dele): servem para reter quem já segue, não para alcançar; primeiro story em foto; não repostar o feed; evitar música por cima.

## Temas que encaixam na Modestino

Caimento e tamanho (como saber se está grande, ombro, comprimento, manga); cuidado com a peça (lavar, secar, guardar, não desbotar); combinação de básicos por ocasião (treino, trabalho, social, cada um com sua peça); erros comuns ao comprar camiseta; bastidores de produção em Fortaleza; perguntas de clientes respondidas uma por lâmina.

## Passo a passo

1. Confirme o objetivo do post (alcance, salvar, comentar, levar para o direct). Se Jorge não disser, use "salvar" para carrossel e "comentar" para post único.
2. Escreva 3 ganchos de capa no método acima e escolha o mais específico. Mostre os 3 só se Jorge quiser escolher.
3. Escreva as lâminas: uma afirmação por lâmina, até ~20 palavras cada. Revise contra as regras da marca.
4. Monte as artes em HTML com as fontes da marca (pacotes npm @fontsource/instrument-sans, @fontsource/instrument-serif, @fontsource/geist-mono) e renderize em PNG 1080×1350 com Playwright (Chromium já instalado em /opt/pw-browsers; use a versão do Playwright que casa com a pasta chromium-NNNN). Arquivos `modestino-<tema>-01.png`, `-02.png`… na ordem.
5. Olhe a prévia uma vez (uma folha com todas as lâminas) antes de entregar.
6. Entregue os PNGs e a legenda pronta para colar. Se Jorge pedir para postar ou agendar, use a habilidade `agendar-post-modestino`.

## Como responder

Curto, em português. Diga o gancho escolhido e por quê em uma linha, entregue as artes e a legenda. Não explique o método a cada vez.