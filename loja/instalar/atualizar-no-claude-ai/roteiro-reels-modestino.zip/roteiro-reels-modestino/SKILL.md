---
name: "roteiro-reels-modestino"
description: "Use quando Jorge pedir roteiro, ideia ou edição de reels/vídeo para o Instagram da Modestino: série de bastidor, frase, resposta a comentário ou detalhe de tecido."
---

# Roteiro de reels da Modestino

Esta habilidade complementa `criar-conteudo-modestino`, que guarda as regras da marca, a identidade e os 5 formatos. Leia essa habilidade e o doc do projeto `claude/referencias-lojas-criadores.md` antes de escrever.

Os reels vêm de quatro escolas:

- Caio no Mundo: série numerada.
- Flávio Augusto: frase forte na tela.
- Tiago Lemos: legenda grande, resposta a comentário, cenário fixo.
- Tailor's Mind e Insider: tecido e produto como protagonistas, gente real vestindo.

## Os 4 tipos de reels

1. **Série (bastidor):** "Lote 01 · Dia N".
   - Abre com o número do episódio e o que vai acontecer ("Dia 04: hoje a malha vira camiseta").
   - Mostra um único momento da produção.
   - Fecha com um gancho para o próximo ("Amanhã: a primeira peça que deu errado").
   - Use sempre o mesmo objeto-símbolo na abertura (a etiqueta MODESTINO, por exemplo) e a mesma capa.
2. **Frase:** Jorge ou Lucas falando de frente.
   - A frase de até 6 palavras aparece numa caixa carvão com texto linho, no terço inferior, nos 2 primeiros segundos.
   - Depois vêm 20 a 35 s de explicação com um exemplo real da marca.
3. **Resposta:** o comentário ou direct real aparece num balão no topo durante todo o vídeo ("Qual tamanho eu uso se tenho 1,75 m?").
   - A resposta é direta, mostrando a peça na mão ou no corpo.
   - Peça a Jorge para confirmar se pode mostrar o nome da pessoa; na dúvida, apague o nome.
4. **Tecido:** de 8 a 15 s, em macro.
   - Mostre o fio, a malha esticando e voltando, a gota de água, a luz atravessando.
   - O nome do tecido aparece na tela em Instrument Serif.
   - Sem fala, com som ambiente.
   - Fale de uma malha por vídeo; o modal é só uma delas.

## Regras de gravação e edição

- **Gancho nos 2 primeiros segundos:** texto na tela e ação ao mesmo tempo. Contrastes que funcionam:
  - "Eu não fiz X";
  - número concreto;
  - pergunta do cliente;
  - erro comum.
- **Legenda grande, palavra a palavra, no centro** (a maioria assiste sem som). Use Instrument Sans 600 em linho com sombra leve ou em carvão sobre faixa linho. Nada de cores fortes.
- **Cenário fixo e reconhecível:** a arara com as peças e a parede neutra do ateliê, sempre no mesmo enquadramento. Grave com luz natural de frente.
- **Duração:** mire cerca de 40 s para fala, 15 s para tecido e até 60 s para série. Corte todos os silêncios.
- **Mão ocupada:** segure a peça, a etiqueta ou a fita métrica. Comece sentado e levante para mostrar a peça vestida (dica do Renato).
- **Último ajuste dentro do Instagram:** título e capa.
- **Capa:**
  - na série, número grande em Instrument Serif;
  - na frase, a frase na caixa carvão;
  - na resposta, o balão da pergunta.
- **Assinatura final:** o cavalheiro pequeno com o nome MODESTINO embaixo, só no último segundo. Nunca no meio do vídeo como assinatura. Na roupa ele pode aparecer, quando a peça for da linha Estampada.
- Descarte imagem tremida, escura ou fora de foco. A marca é premium.

## Passo a passo

1. Escolha o tipo, olhando o que foi postado por último para manter a grade alternada.
2. Entregue o roteiro em tabela: tempo, o que aparece, o que é dito, o texto na tela.
3. Escreva a lista de tomadas para gravar no celular: enquadramento, distância, luz e duração de cada uma.
4. Escreva a legenda curta, com pergunta e palavra-chave para comentar.
5. Se Jorge mandar o vídeo bruto, sugira os cortes por minutagem e os textos de tela. Se houver ferramenta de edição disponível, prepare a versão editada. Gere as artes de capa e as caixas de texto em PNG com as fontes da marca, como em `criar-conteudo-modestino`.
6. Apresente a Jorge antes de qualquer agendamento. Agende só depois da aprovação, com `agendar-post-modestino`.

## Como responder

Curto, em português. Uma linha com o tipo e o gancho, depois o roteiro em tabela, as tomadas e a legenda.